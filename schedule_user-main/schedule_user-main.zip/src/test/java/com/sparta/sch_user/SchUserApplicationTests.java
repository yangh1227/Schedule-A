package com.sparta.sch_user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchUserApplicationTests {

    @Test
    void contextLoads() {
    }

}
